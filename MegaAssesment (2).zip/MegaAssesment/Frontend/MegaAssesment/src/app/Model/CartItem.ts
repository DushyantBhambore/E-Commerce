export interface CartItem {
    productId: number;
    productCode: string;
    saleQty: number;
    sellingPrice: number;
  }