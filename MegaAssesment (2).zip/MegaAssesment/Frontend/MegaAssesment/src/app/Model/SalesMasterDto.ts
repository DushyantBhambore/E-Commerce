export interface PaymentResponseModel {
    statusCode: number;
    message: string;
    data: any;
  }
  