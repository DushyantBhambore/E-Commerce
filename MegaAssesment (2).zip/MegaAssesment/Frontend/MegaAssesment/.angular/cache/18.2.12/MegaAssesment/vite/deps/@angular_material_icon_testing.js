import {
  MatIconRegistry
} from "./chunk-LVWBXFD6.js";
import "./chunk-JKF6AHPO.js";
import "./chunk-NS325BZG.js";
import "./chunk-KUBVR5M4.js";
import "./chunk-VUSIUU2D.js";
import "./chunk-ET5SAGGE.js";
import "./chunk-JS2GI3JY.js";
import {
  Injectable,
  NgModule,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-JYXXJTPI.js";
import {
  BehaviorSubject,
  __async,
  of
} from "./chunk-5TID76VL.js";

// node_modules/@angular/cdk/fesm2022/testing.mjs
var autoChangeDetectionSubject = new BehaviorSubject({
  isDisabled: false
});
var autoChangeDetectionSubscription;
function defaultAutoChangeDetectionHandler(status) {
  status.onDetectChangesNow?.();
}
function handleAutoChangeDetectionStatus(handler) {
  stopHandlingAutoChangeDetectionStatus();
  autoChangeDetectionSubscription = autoChangeDetectionSubject.subscribe(handler);
}
function stopHandlingAutoChangeDetectionStatus() {
  autoChangeDetectionSubscription?.unsubscribe();
  autoChangeDetectionSubscription = null;
}
function batchChangeDetection(fn, triggerBeforeAndAfter) {
  return __async(this, null, function* () {
    if (autoChangeDetectionSubject.getValue().isDisabled) {
      return yield fn();
    }
    if (!autoChangeDetectionSubscription) {
      handleAutoChangeDetectionStatus(defaultAutoChangeDetectionHandler);
    }
    if (triggerBeforeAndAfter) {
      yield new Promise((resolve) => autoChangeDetectionSubject.next({
        isDisabled: true,
        onDetectChangesNow: resolve
      }));
      try {
        return yield fn();
      } finally {
        yield new Promise((resolve) => autoChangeDetectionSubject.next({
          isDisabled: false,
          onDetectChangesNow: resolve
        }));
      }
    } else {
      autoChangeDetectionSubject.next({
        isDisabled: true
      });
      try {
        return yield fn();
      } finally {
        autoChangeDetectionSubject.next({
          isDisabled: false
        });
      }
    }
  });
}
function parallel(values) {
  return __async(this, null, function* () {
    return batchChangeDetection(() => Promise.all(values()), true);
  });
}
var ComponentHarness = class {
  constructor(locatorFactory) {
    this.locatorFactory = locatorFactory;
  }
  /** Gets a `Promise` for the `TestElement` representing the host element of the component. */
  host() {
    return __async(this, null, function* () {
      return this.locatorFactory.rootElement;
    });
  }
  /**
   * Gets a `LocatorFactory` for the document root element. This factory can be used to create
   * locators for elements that a component creates outside of its own root element. (e.g. by
   * appending to document.body).
   */
  documentRootLocatorFactory() {
    return this.locatorFactory.documentRootLocatorFactory();
  }
  /**
   * Creates an asynchronous locator function that can be used to find a `ComponentHarness` instance
   * or element under the host element of this `ComponentHarness`.
   * @param queries A list of queries specifying which harnesses and elements to search for:
   *   - A `string` searches for elements matching the CSS selector specified by the string.
   *   - A `ComponentHarness` constructor searches for `ComponentHarness` instances matching the
   *     given class.
   *   - A `HarnessPredicate` searches for `ComponentHarness` instances matching the given
   *     predicate.
   * @return An asynchronous locator function that searches for and returns a `Promise` for the
   *   first element or harness matching the given search criteria. Matches are ordered first by
   *   order in the DOM, and second by order in the queries list. If no matches are found, the
   *   `Promise` rejects. The type that the `Promise` resolves to is a union of all result types for
   *   each query.
   *
   * e.g. Given the following DOM: `<div id="d1" /><div id="d2" />`, and assuming
   * `DivHarness.hostSelector === 'div'`:
   * - `await ch.locatorFor(DivHarness, 'div')()` gets a `DivHarness` instance for `#d1`
   * - `await ch.locatorFor('div', DivHarness)()` gets a `TestElement` instance for `#d1`
   * - `await ch.locatorFor('span')()` throws because the `Promise` rejects.
   */
  locatorFor(...queries) {
    return this.locatorFactory.locatorFor(...queries);
  }
  /**
   * Creates an asynchronous locator function that can be used to find a `ComponentHarness` instance
   * or element under the host element of this `ComponentHarness`.
   * @param queries A list of queries specifying which harnesses and elements to search for:
   *   - A `string` searches for elements matching the CSS selector specified by the string.
   *   - A `ComponentHarness` constructor searches for `ComponentHarness` instances matching the
   *     given class.
   *   - A `HarnessPredicate` searches for `ComponentHarness` instances matching the given
   *     predicate.
   * @return An asynchronous locator function that searches for and returns a `Promise` for the
   *   first element or harness matching the given search criteria. Matches are ordered first by
   *   order in the DOM, and second by order in the queries list. If no matches are found, the
   *   `Promise` is resolved with `null`. The type that the `Promise` resolves to is a union of all
   *   result types for each query or null.
   *
   * e.g. Given the following DOM: `<div id="d1" /><div id="d2" />`, and assuming
   * `DivHarness.hostSelector === 'div'`:
   * - `await ch.locatorForOptional(DivHarness, 'div')()` gets a `DivHarness` instance for `#d1`
   * - `await ch.locatorForOptional('div', DivHarness)()` gets a `TestElement` instance for `#d1`
   * - `await ch.locatorForOptional('span')()` gets `null`.
   */
  locatorForOptional(...queries) {
    return this.locatorFactory.locatorForOptional(...queries);
  }
  /**
   * Creates an asynchronous locator function that can be used to find `ComponentHarness` instances
   * or elements under the host element of this `ComponentHarness`.
   * @param queries A list of queries specifying which harnesses and elements to search for:
   *   - A `string` searches for elements matching the CSS selector specified by the string.
   *   - A `ComponentHarness` constructor searches for `ComponentHarness` instances matching the
   *     given class.
   *   - A `HarnessPredicate` searches for `ComponentHarness` instances matching the given
   *     predicate.
   * @return An asynchronous locator function that searches for and returns a `Promise` for all
   *   elements and harnesses matching the given search criteria. Matches are ordered first by
   *   order in the DOM, and second by order in the queries list. If an element matches more than
   *   one `ComponentHarness` class, the locator gets an instance of each for the same element. If
   *   an element matches multiple `string` selectors, only one `TestElement` instance is returned
   *   for that element. The type that the `Promise` resolves to is an array where each element is
   *   the union of all result types for each query.
   *
   * e.g. Given the following DOM: `<div id="d1" /><div id="d2" />`, and assuming
   * `DivHarness.hostSelector === 'div'` and `IdIsD1Harness.hostSelector === '#d1'`:
   * - `await ch.locatorForAll(DivHarness, 'div')()` gets `[
   *     DivHarness, // for #d1
   *     TestElement, // for #d1
   *     DivHarness, // for #d2
   *     TestElement // for #d2
   *   ]`
   * - `await ch.locatorForAll('div', '#d1')()` gets `[
   *     TestElement, // for #d1
   *     TestElement // for #d2
   *   ]`
   * - `await ch.locatorForAll(DivHarness, IdIsD1Harness)()` gets `[
   *     DivHarness, // for #d1
   *     IdIsD1Harness, // for #d1
   *     DivHarness // for #d2
   *   ]`
   * - `await ch.locatorForAll('span')()` gets `[]`.
   */
  locatorForAll(...queries) {
    return this.locatorFactory.locatorForAll(...queries);
  }
  /**
   * Flushes change detection and async tasks in the Angular zone.
   * In most cases it should not be necessary to call this manually. However, there may be some edge
   * cases where it is needed to fully flush animation events.
   */
  forceStabilize() {
    return __async(this, null, function* () {
      return this.locatorFactory.forceStabilize();
    });
  }
  /**
   * Waits for all scheduled or running async tasks to complete. This allows harness
   * authors to wait for async tasks outside of the Angular zone.
   */
  waitForTasksOutsideAngular() {
    return __async(this, null, function* () {
      return this.locatorFactory.waitForTasksOutsideAngular();
    });
  }
};
var HarnessPredicate = class {
  constructor(harnessType, options) {
    this.harnessType = harnessType;
    this._predicates = [];
    this._descriptions = [];
    this._addBaseOptions(options);
  }
  /**
   * Checks if the specified nullable string value matches the given pattern.
   * @param value The nullable string value to check, or a Promise resolving to the
   *   nullable string value.
   * @param pattern The pattern the value is expected to match. If `pattern` is a string,
   *   `value` is expected to match exactly. If `pattern` is a regex, a partial match is
   *   allowed. If `pattern` is `null`, the value is expected to be `null`.
   * @return Whether the value matches the pattern.
   */
  static stringMatches(value, pattern) {
    return __async(this, null, function* () {
      value = yield value;
      if (pattern === null) {
        return value === null;
      } else if (value === null) {
        return false;
      }
      return typeof pattern === "string" ? value === pattern : pattern.test(value);
    });
  }
  /**
   * Adds a predicate function to be run against candidate harnesses.
   * @param description A description of this predicate that may be used in error messages.
   * @param predicate An async predicate function.
   * @return this (for method chaining).
   */
  add(description, predicate) {
    this._descriptions.push(description);
    this._predicates.push(predicate);
    return this;
  }
  /**
   * Adds a predicate function that depends on an option value to be run against candidate
   * harnesses. If the option value is undefined, the predicate will be ignored.
   * @param name The name of the option (may be used in error messages).
   * @param option The option value.
   * @param predicate The predicate function to run if the option value is not undefined.
   * @return this (for method chaining).
   */
  addOption(name, option, predicate) {
    if (option !== void 0) {
      this.add(`${name} = ${_valueAsString(option)}`, (item) => predicate(item, option));
    }
    return this;
  }
  /**
   * Filters a list of harnesses on this predicate.
   * @param harnesses The list of harnesses to filter.
   * @return A list of harnesses that satisfy this predicate.
   */
  filter(harnesses) {
    return __async(this, null, function* () {
      if (harnesses.length === 0) {
        return [];
      }
      const results = yield parallel(() => harnesses.map((h) => this.evaluate(h)));
      return harnesses.filter((_, i) => results[i]);
    });
  }
  /**
   * Evaluates whether the given harness satisfies this predicate.
   * @param harness The harness to check
   * @return A promise that resolves to true if the harness satisfies this predicate,
   *   and resolves to false otherwise.
   */
  evaluate(harness) {
    return __async(this, null, function* () {
      const results = yield parallel(() => this._predicates.map((p) => p(harness)));
      return results.reduce((combined, current) => combined && current, true);
    });
  }
  /** Gets a description of this predicate for use in error messages. */
  getDescription() {
    return this._descriptions.join(", ");
  }
  /** Gets the selector used to find candidate elements. */
  getSelector() {
    if (!this._ancestor) {
      return (this.harnessType.hostSelector || "").trim();
    }
    const [ancestors, ancestorPlaceholders] = _splitAndEscapeSelector(this._ancestor);
    const [selectors, selectorPlaceholders] = _splitAndEscapeSelector(this.harnessType.hostSelector || "");
    const result = [];
    ancestors.forEach((escapedAncestor) => {
      const ancestor = _restoreSelector(escapedAncestor, ancestorPlaceholders);
      return selectors.forEach((escapedSelector) => result.push(`${ancestor} ${_restoreSelector(escapedSelector, selectorPlaceholders)}`));
    });
    return result.join(", ");
  }
  /** Adds base options common to all harness types. */
  _addBaseOptions(options) {
    this._ancestor = options.ancestor || "";
    if (this._ancestor) {
      this._descriptions.push(`has ancestor matching selector "${this._ancestor}"`);
    }
    const selector = options.selector;
    if (selector !== void 0) {
      this.add(`host matches selector "${selector}"`, (item) => __async(this, null, function* () {
        return (yield item.host()).matchesSelector(selector);
      }));
    }
  }
};
function _valueAsString(value) {
  if (value === void 0) {
    return "undefined";
  }
  try {
    const stringifiedValue = JSON.stringify(value, (_, v) => v instanceof RegExp ? `◬MAT_RE_ESCAPE◬${v.toString().replace(/"/g, "◬MAT_RE_ESCAPE◬")}◬MAT_RE_ESCAPE◬` : v);
    return stringifiedValue.replace(/"◬MAT_RE_ESCAPE◬|◬MAT_RE_ESCAPE◬"/g, "").replace(/◬MAT_RE_ESCAPE◬/g, '"');
  } catch {
    return "{...}";
  }
}
function _splitAndEscapeSelector(selector) {
  const placeholders = [];
  const result = selector.replace(/(["'][^["']*["'])/g, (_, keep) => {
    const replaceBy = `__cdkPlaceholder-${placeholders.length}__`;
    placeholders.push(keep);
    return replaceBy;
  });
  return [result.split(",").map((part) => part.trim()), placeholders];
}
function _restoreSelector(selector, placeholders) {
  return selector.replace(/__cdkPlaceholder-(\d+)__/g, (_, index) => placeholders[+index]);
}
var TestKey;
(function(TestKey2) {
  TestKey2[TestKey2["BACKSPACE"] = 0] = "BACKSPACE";
  TestKey2[TestKey2["TAB"] = 1] = "TAB";
  TestKey2[TestKey2["ENTER"] = 2] = "ENTER";
  TestKey2[TestKey2["SHIFT"] = 3] = "SHIFT";
  TestKey2[TestKey2["CONTROL"] = 4] = "CONTROL";
  TestKey2[TestKey2["ALT"] = 5] = "ALT";
  TestKey2[TestKey2["ESCAPE"] = 6] = "ESCAPE";
  TestKey2[TestKey2["PAGE_UP"] = 7] = "PAGE_UP";
  TestKey2[TestKey2["PAGE_DOWN"] = 8] = "PAGE_DOWN";
  TestKey2[TestKey2["END"] = 9] = "END";
  TestKey2[TestKey2["HOME"] = 10] = "HOME";
  TestKey2[TestKey2["LEFT_ARROW"] = 11] = "LEFT_ARROW";
  TestKey2[TestKey2["UP_ARROW"] = 12] = "UP_ARROW";
  TestKey2[TestKey2["RIGHT_ARROW"] = 13] = "RIGHT_ARROW";
  TestKey2[TestKey2["DOWN_ARROW"] = 14] = "DOWN_ARROW";
  TestKey2[TestKey2["INSERT"] = 15] = "INSERT";
  TestKey2[TestKey2["DELETE"] = 16] = "DELETE";
  TestKey2[TestKey2["F1"] = 17] = "F1";
  TestKey2[TestKey2["F2"] = 18] = "F2";
  TestKey2[TestKey2["F3"] = 19] = "F3";
  TestKey2[TestKey2["F4"] = 20] = "F4";
  TestKey2[TestKey2["F5"] = 21] = "F5";
  TestKey2[TestKey2["F6"] = 22] = "F6";
  TestKey2[TestKey2["F7"] = 23] = "F7";
  TestKey2[TestKey2["F8"] = 24] = "F8";
  TestKey2[TestKey2["F9"] = 25] = "F9";
  TestKey2[TestKey2["F10"] = 26] = "F10";
  TestKey2[TestKey2["F11"] = 27] = "F11";
  TestKey2[TestKey2["F12"] = 28] = "F12";
  TestKey2[TestKey2["META"] = 29] = "META";
  TestKey2[TestKey2["COMMA"] = 30] = "COMMA";
})(TestKey || (TestKey = {}));

// node_modules/@angular/material/fesm2022/icon/testing.mjs
var MatIconHarness = class _MatIconHarness extends ComponentHarness {
  static {
    this.hostSelector = ".mat-icon";
  }
  /**
   * Gets a `HarnessPredicate` that can be used to search for a `MatIconHarness` that meets
   * certain criteria.
   * @param options Options for filtering which icon instances are considered a match.
   * @return a `HarnessPredicate` configured with the given options.
   */
  static with(options = {}) {
    return new HarnessPredicate(_MatIconHarness, options).addOption("type", options.type, (harness, type) => __async(this, null, function* () {
      return (yield harness.getType()) === type;
    })).addOption("name", options.name, (harness, text) => HarnessPredicate.stringMatches(harness.getName(), text)).addOption("namespace", options.namespace, (harness, text) => HarnessPredicate.stringMatches(harness.getNamespace(), text));
  }
  /** Gets the type of the icon. */
  getType() {
    return __async(this, null, function* () {
      const type = yield (yield this.host()).getAttribute("data-mat-icon-type");
      return type === "svg" ? 0 : 1;
    });
  }
  /** Gets the name of the icon. */
  getName() {
    return __async(this, null, function* () {
      const host = yield this.host();
      const nameFromDom = yield host.getAttribute("data-mat-icon-name");
      if (nameFromDom) {
        return nameFromDom;
      }
      if ((yield this.getType()) === 1) {
        const text = yield host.text({
          exclude: "*"
        });
        return text.length > 0 ? text : host.text();
      }
      return null;
    });
  }
  /** Gets the namespace of the icon. */
  getNamespace() {
    return __async(this, null, function* () {
      return (yield this.host()).getAttribute("data-mat-icon-namespace");
    });
  }
  /** Gets whether the icon is inline. */
  isInline() {
    return __async(this, null, function* () {
      return (yield this.host()).hasClass("mat-icon-inline");
    });
  }
};
var FakeMatIconRegistry = class _FakeMatIconRegistry {
  addSvgIcon() {
    return this;
  }
  addSvgIconLiteral() {
    return this;
  }
  addSvgIconInNamespace() {
    return this;
  }
  addSvgIconLiteralInNamespace() {
    return this;
  }
  addSvgIconSet() {
    return this;
  }
  addSvgIconSetLiteral() {
    return this;
  }
  addSvgIconSetInNamespace() {
    return this;
  }
  addSvgIconSetLiteralInNamespace() {
    return this;
  }
  registerFontClassAlias() {
    return this;
  }
  classNameForFontAlias(alias) {
    return alias;
  }
  getDefaultFontSetClass() {
    return ["material-icons"];
  }
  getSvgIconFromUrl() {
    return of(this._generateEmptySvg());
  }
  getNamedSvgIcon() {
    return of(this._generateEmptySvg());
  }
  setDefaultFontSetClass() {
    return this;
  }
  addSvgIconResolver() {
    return this;
  }
  ngOnDestroy() {
  }
  _generateEmptySvg() {
    const emptySvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    emptySvg.classList.add("fake-testing-svg");
    emptySvg.setAttribute("fit", "");
    emptySvg.setAttribute("height", "100%");
    emptySvg.setAttribute("width", "100%");
    emptySvg.setAttribute("preserveAspectRatio", "xMidYMid meet");
    emptySvg.setAttribute("focusable", "false");
    return emptySvg;
  }
  static {
    this.ɵfac = function FakeMatIconRegistry_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _FakeMatIconRegistry)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _FakeMatIconRegistry,
      factory: _FakeMatIconRegistry.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FakeMatIconRegistry, [{
    type: Injectable
  }], null, null);
})();
var MatIconTestingModule = class _MatIconTestingModule {
  static {
    this.ɵfac = function MatIconTestingModule_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _MatIconTestingModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _MatIconTestingModule
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      providers: [{
        provide: MatIconRegistry,
        useClass: FakeMatIconRegistry
      }]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MatIconTestingModule, [{
    type: NgModule,
    args: [{
      providers: [{
        provide: MatIconRegistry,
        useClass: FakeMatIconRegistry
      }]
    }]
  }], null, null);
})();
export {
  FakeMatIconRegistry,
  MatIconHarness,
  MatIconTestingModule
};
//# sourceMappingURL=@angular_material_icon_testing.js.map
