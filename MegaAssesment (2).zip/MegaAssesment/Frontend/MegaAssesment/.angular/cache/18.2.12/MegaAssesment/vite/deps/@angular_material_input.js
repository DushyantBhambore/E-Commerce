import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-6GN42ASD.js";
import "./chunk-WCKZMKEI.js";
import "./chunk-7VA4HQRV.js";
import "./chunk-JKF6AHPO.js";
import "./chunk-NS325BZG.js";
import "./chunk-KUBVR5M4.js";
import "./chunk-VUSIUU2D.js";
import "./chunk-ET5SAGGE.js";
import "./chunk-JS2GI3JY.js";
import "./chunk-JYXXJTPI.js";
import "./chunk-5TID76VL.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
