import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-NOSF7ETU.js";
import "./chunk-7VA4HQRV.js";
import "./chunk-LINWZ6CV.js";
import "./chunk-OPXIEEHW.js";
import "./chunk-VBUWOP2O.js";
import "./chunk-WQ2GAAJG.js";
import "./chunk-VUSIUU2D.js";
import "./chunk-ET5SAGGE.js";
import "./chunk-JS2GI3JY.js";
import "./chunk-JYXXJTPI.js";
import "./chunk-5TID76VL.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
