import { Component } from '@angular/core';

@Component({
  selector: 'app-change-passowrd',
  standalone: true,
  imports: [],
  templateUrl: './change-passowrd.component.html',
  styleUrl: './change-passowrd.component.css'
})
export class ChangePassowrdComponent {

}
