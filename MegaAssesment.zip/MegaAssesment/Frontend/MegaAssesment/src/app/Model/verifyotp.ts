export interface IVerifyOtpDto{
    username: string,
    otp: string
}