export interface ProductDTo{
     prodcutId : number 

     productName :string
   
     productImage :string 
   
     category :string 
   
     brand:string 
   
    sellingPrice :number 
   
     purchasePrice : number 
   
     purchaseDate :Date 
   
     stock:number 
}