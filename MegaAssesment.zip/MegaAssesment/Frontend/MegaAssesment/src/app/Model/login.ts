export interface ILoginDto{
  username: string,
  password: string
} 