export interface GetCartDto
{
    
}